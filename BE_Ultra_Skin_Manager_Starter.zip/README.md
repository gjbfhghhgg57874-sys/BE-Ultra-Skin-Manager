# BE Ultra Skin Manager — Starter (Minecraft Bedrock / Android)

This is a starter project, not a finished installer. It deliberately starts with a simple UI and safe, local skin catalog.

## Important compatibility notes
- A normal Bedrock `.mcaddon` cannot replace other players' actual player skins by Xbox Gamertag in a regular multiplayer world.
- A companion Android app cannot silently install a skin into an Xbox account or change that account's official skin.
- The 512–1024 px input sizes are accepted as source images by the sample catalog, but that does NOT guarantee Bedrock will render them at that resolution. Bedrock skin formats and supported dimensions must be validated against the exact game version.
- This starter does not upload images, request Xbox credentials, or modify accounts.

## Included
- `android_app/`: minimal Android Studio project shell with a simple screen for adding a Gamertag label and selecting a local image.
- `addon/`: a minimal Bedrock pack skeleton for testing pack import; it does not implement per-player skin replacement.
- `skin_catalog_example.json`: example local catalog structure.

## Next steps
1. Open `android_app` in Android Studio.
2. Build/run on an Android device. Depending on your Android Studio version, you may need to create/sync a Gradle wrapper/project metadata.
3. Test the `.mcaddon` by importing it into Minecraft Bedrock. It is only a pack skeleton, not the promised automatic multiplayer skin system.
4. For real multiplayer skin visibility, use Minecraft-supported skin mechanisms or a server/plugin architecture that explicitly supports the target platform; ordinary behavior/resource packs alone are insufficient.
