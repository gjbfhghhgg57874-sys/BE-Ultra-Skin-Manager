This resource pack is intentionally empty. It does not override player skins.
