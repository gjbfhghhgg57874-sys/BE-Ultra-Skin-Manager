package com.example.ultraskin;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Minimal starter UI. Stores only the currently selected image URI and Gamertag label.
 * This is not a complete persistent catalog and does not modify Xbox/Minecraft accounts.
 */
public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 101;
    private EditText gamertagInput;
    private TextView selectedText;
    private ImageView preview;
    private Uri selectedImage;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("BE Ultra Skin Manager");
        title.setTextSize(24);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("ต้นแบบเรียบง่าย • เลือกรูปและใส่ Gamertag");
        subtitle.setTextSize(14);
        root.addView(subtitle);

        gamertagInput = new EditText(this);
        gamertagInput.setHint("Xbox Gamertag (ชื่อแสดงผลเท่านั้น)");
        root.addView(gamertagInput);

        Button pick = new Button(this);
        pick.setText("เลือกรูปสกิน");
        root.addView(pick);

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setMaxHeight(500);
        root.addView(preview);

        selectedText = new TextView(this);
        selectedText.setText("ยังไม่ได้เลือกรูป");
        root.addView(selectedText);

        Button save = new Button(this);
        save.setText("ตรวจสอบข้อมูล");
        root.addView(save);

        TextView note = new TextView(this);
        note.setText("หมายเหตุ: แอปต้นแบบนี้ยังไม่เปลี่ยนสกินใน Xbox หรือทำให้ผู้เล่นอื่นเห็นสกินอัตโนมัติ");
        root.addView(note);

        pick.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE);
        });

        save.setOnClickListener(v -> {
            String tag = gamertagInput.getText().toString().trim();
            if (tag.isEmpty()) {
                Toast.makeText(this, "กรุณาใส่ Xbox Gamertag", Toast.LENGTH_SHORT).show();
            } else if (selectedImage == null) {
                Toast.makeText(this, "กรุณาเลือกรูปสกินก่อน", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "ตรวจสอบแล้ว: " + tag + " (ยังไม่ได้บันทึกถาวร)", Toast.LENGTH_LONG).show();
            }
        });

        setContentView(root);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImage = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                    selectedImage, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            preview.setImageURI(selectedImage);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            try (java.io.InputStream in = getContentResolver().openInputStream(selectedImage)) {
                BitmapFactory.decodeStream(in, null, opts);
                selectedText.setText("รูปที่เลือก: " + opts.outWidth + "×" + opts.outHeight);
            } catch (Exception e) {
                selectedText.setText("เลือกรูปแล้ว แต่ไม่สามารถอ่านขนาดภาพได้");
            }
        }
    }
}
